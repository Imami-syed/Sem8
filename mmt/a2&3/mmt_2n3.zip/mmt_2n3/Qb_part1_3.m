l=2;
h=0.05;
s = "Autocor";
mirtempo('./samples/michael_jackson.wav','Frame',l)
mirtempo('./samples/mozart.wav','Frame',l)
